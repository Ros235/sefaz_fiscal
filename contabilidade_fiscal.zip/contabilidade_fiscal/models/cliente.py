from db.database import get_db_connection

class Cliente:
    def __init__(self, id=None, nome=None, cnpj=None, certificado_path=None, senha_certificado=None):
        self.id = id
        self.nome = nome
        self.cnpj = cnpj
        self.certificado_path = certificado_path
        self.senha_certificado = senha_certificado

    @classmethod
    def create_table(cls):
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS clientes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL,
                cnpj TEXT NOT NULL UNIQUE,
                certificado_path TEXT NOT NULL,
                senha_certificado TEXT
            )
        """)
        conn.commit()
        conn.close()

    @classmethod
    def get_all(cls):
      conn = get_db_connection()
      cursor = conn.cursor()
      cursor.execute("SELECT * FROM clientes")
      rows = cursor.fetchall()
      conn.close()
      return [cls(**dict(row)) for row in rows]


    @classmethod
    def get_by_id(cls, id):
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM clientes WHERE id = ?", (id,))
        row = cursor.fetchone()
        conn.close()
        return cls(**dict(row)) if row else None

    @classmethod
    def get_by_cnpj(cls, cnpj):
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM clientes WHERE cnpj = ?", (cnpj,))
        row = cursor.fetchone()
        conn.close()
        return cls(**dict(row)) if row else None

    @classmethod
    def add(cls, nome, cnpj, certificado_path, senha_certificado):
        conn = get_db_connection()
        cursor = conn.cursor()
        try:
           cursor.execute("INSERT INTO clientes (nome, cnpj, certificado_path, senha_certificado) VALUES (?, ?, ?, ?)",
                        (nome, cnpj, certificado_path, senha_certificado))
           conn.commit()
           id = cursor.lastrowid
        except sqlite3.IntegrityError:
             conn.rollback()
             conn.close()
             return None
        finally:
            conn.close()
        return cls(id=id, nome=nome, cnpj=cnpj, certificado_path=certificado_path, senha_certificado=senha_certificado)

    def update(self):
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("UPDATE clientes SET nome = ?, cnpj = ?, certificado_path = ?, senha_certificado = ? WHERE id = ?",
                    (self.nome, self.cnpj, self.certificado_path, self.senha_certificado, self.id))
        conn.commit()
        conn.close()

    def delete(self):
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM clientes WHERE id = ?", (self.id,))
        conn.commit()
        conn.close()

    def __repr__(self):
        return f"<Cliente(id={self.id}, nome='{self.nome}', cnpj='{self.cnpj}')>"