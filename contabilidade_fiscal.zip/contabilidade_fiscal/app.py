from flask import Flask, render_template, request, redirect, url_for, session
from controllers import cliente_controller
from controllers import nota_fiscal_controller
import logging

app = Flask(__name__)
app.secret_key = 'chave_secreta'


logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')


@app.route('/')
def index():
    logging.debug("Acessando a rota '/'")
    return render_template('index.html')

@app.route('/clientes', methods=['GET', 'POST'])
def clientes():
  logging.debug("Acessando a rota '/clientes'")
  if request.method == 'POST':
    logging.debug("Método POST recebido, encaminhando para cliente_controller.add_cliente")
    return cliente_controller.add_cliente(request)
  else:
    logging.debug("Método GET recebido, encaminhando para cliente_controller.list_clientes")
    return cliente_controller.list_clientes()

@app.route('/clientes/<int:cliente_id>/notas')
def notas(cliente_id):
   return nota_fiscal_controller.consultar_notas(cliente_id)

@app.route('/clientes/<int:cliente_id>/delete')
def delete(cliente_id):
   return cliente_controller.delete_cliente(cliente_id)


if __name__ == '__main__':
    logging.debug("Iniciando a aplicação")
    app.run(debug=True)