import sqlite3
import os

DATABASE_PATH = os.path.join(os.path.dirname(__file__), 'contabilidade_fiscal.db')

def get_db_connection():
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row  # Para acessar as colunas pelo nome
    return conn

def init_db():
    conn = get_db_connection()
    cursor = conn.cursor()
    # Cria a tabela clientes (se não existir)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS clientes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            cnpj TEXT NOT NULL UNIQUE,
            certificado_path TEXT NOT NULL,
            senha_certificado TEXT
        )
    """)
    conn.commit()
    conn.close()

if __name__ == '__main__':
    init_db()
    print("Banco de dados criado e inicializado!")