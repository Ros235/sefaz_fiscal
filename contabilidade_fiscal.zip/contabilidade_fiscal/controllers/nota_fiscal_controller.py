from flask import render_template, request, redirect, url_for, session
from models.cliente import Cliente
from controllers.sefaz_api import SefazAPI

def consultar_notas(cliente_id):
  cliente = Cliente.get_by_id(cliente_id)
  if cliente:
    sefaz = SefazAPI(cliente.certificado_path, cliente.senha_certificado)
    xml_dict = sefaz.consultar_nfe(cliente.cnpj)
    if xml_dict:
      return render_template('notas.html', xml_dict = xml_dict, cliente = cliente)
    else:
      return render_template('notas.html', error='Erro ao consultar as notas fiscais.', cliente = cliente)
  else:
     return render_template('notas.html', error='Cliente não encontrado.')