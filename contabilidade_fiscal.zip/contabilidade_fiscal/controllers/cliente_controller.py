from flask import render_template, request, redirect, url_for
from models.cliente import Cliente
import logging

def list_clientes():
  logging.debug("Executando list_clientes")
  clientes = Cliente.get_all()
  logging.debug(f"Clientes obtidos: {clientes}")
  return render_template('clientes.html', clientes=clientes)


def add_cliente(request):
  logging.debug("Executando add_cliente")
  nome = request.form['nome']
  cnpj = request.form['cnpj']
  certificado_path = request.form['certificado_path']
  senha_certificado = request.form['senha_certificado']
  logging.debug(f"Dados do formulário: nome={nome}, cnpj={cnpj}, certificado_path={certificado_path}")

  cliente = Cliente.add(nome, cnpj, certificado_path, senha_certificado)
  if cliente:
     logging.debug(f"Cliente adicionado: {cliente}")
     return redirect(url_for('clientes'))
  else:
    logging.debug("Erro ao adicionar cliente (CNPJ já cadastrado)")
    return render_template('clientes.html', error='CNPJ já cadastrado.')


def delete_cliente(cliente_id):
    logging.debug(f"Excluindo cliente com id: {cliente_id}")
    cliente = Cliente.get_by_id(cliente_id)
    if cliente:
       cliente.delete()
       logging.debug(f"Cliente com id: {cliente_id} excluído com sucesso.")
    else:
       logging.debug(f"Cliente com id: {cliente_id} não encontrado")
    return redirect(url_for('clientes'))