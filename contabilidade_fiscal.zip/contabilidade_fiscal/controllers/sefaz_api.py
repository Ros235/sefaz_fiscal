import requests
import xmltodict
from cryptography import x509
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.backends import default_backend
import base64
from datetime import datetime
import logging
import textwrap


class SefazAPI:
    def __init__(self, certificado_path, senha_certificado):
        logging.debug(f"Certificado path recebido: {certificado_path}")
        self.certificado_path = certificado_path
        self.senha_certificado = senha_certificado
        self.chave_publica = None
        self.certificado_base64 = None
        self._carregar_certificado()

    def _carregar_certificado(self):
        with open(self.certificado_path, 'rb') as f:
            certificado_bytes = f.read()
        try:
            certificado = serialization.pkcs12.load_key_and_certificates(certificado_bytes, password=self.senha_certificado.encode(), backend=default_backend())
            certificado_obj = certificado[1][0]
        except Exception as e:
            certificado = serialization.pkcs12.load_key_and_certificates(certificado_bytes, password=None, backend=default_backend())
            certificado_obj = certificado[1][0]

        self.chave_publica = certificado_obj.public_key()
        self.certificado_base64 = base64.b64encode(crypto.dump_certificate(crypto.FILETYPE_PEM, certificado_obj)).decode('utf-8')

    def _assinar_xml(self, xml_string):
        private_key = None
        with open(self.certificado_path, 'rb') as f:
            certificado_bytes = f.read()
        try:
            certificado = serialization.pkcs12.load_key_and_certificates(certificado_bytes, password=self.senha_certificado.encode(), backend=default_backend())
            private_key = certificado[0]
        except Exception as e:
            certificado = serialization.pkcs12.load_key_and_certificates(certificado_bytes, password=None, backend=default_backend())
            private_key = certificado[0]


        signer = private_key.signer(
            padding.PKCS1v15(), hashes.SHA1()
        )
        signer.update(xml_string.encode('utf-8'))
        signature = signer.finalize()
        signature_base64 = base64.b64encode(signature).decode('utf-8')
        return signature_base64

    def _montar_cabecalho(self, xml_string):
        signature_base64 = self._assinar_xml(xml_string)
        data_e_hora = datetime.now().strftime('%Y-%m-%dT%H:%M:%S-03:00')
        xml_cabecalho = textwrap.dedent(
            """
            <soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:nfe="http://www.portalfiscal.inf.br/nfe/wsdl/NFeDistribuicaoDFe">
              <soap:Header>
                <nfe:nfeCabecMsg soap:mustUnderstand="1">
                  <nfe:cUF>35</nfe:cUF>
                  <nfe:versaoDados>1.00</nfe:versaoDados>
                  <nfe:Signature xmlns="http://www.w3.org/2000/09/xmldsig#">
                    <nfe:SignedInfo>
                      <nfe:CanonicalizationMethod Algorithm="http://www.w3.org/2001/10/xml-exc-c14n#"/>
                      <nfe:SignatureMethod Algorithm="http://www.w3.org/2000/09/xmldsig#rsa-sha1"/>
                      <nfe:Reference URI="">
                        <nfe:Transforms>
                          <nfe:Transform Algorithm="http://www.w3.org/2000/09/xmldsig#enveloped-signature"/>
                          <nfe:Transform Algorithm="http://www.w3.org/2001/10/xml-exc-c14n#"/>
                        </nfe:Transforms>
                        <nfe:DigestMethod Algorithm="http://www.w3.org/2000/09/xmldsig#sha1"/>
                        <nfe:DigestValue></nfe:DigestValue>
                      </nfe:Reference>
                    </nfe:SignedInfo>
                    <nfe:SignatureValue>{}</nfe:SignatureValue>
                    <nfe:KeyInfo>
                      <nfe:X509Data>
                        <nfe:X509Certificate>{}</nfe:X509Certificate>
                      </nfe:X509Data>
                    </nfe:KeyInfo>
                  </nfe:Signature>
                </nfe:nfeCabecMsg>
              </soap:Header>
              <soap:Body>
                <nfe:nfeDistDFeInteresse>
                  <nfe:distDFeInt>
                      <nfe:tpAmb>1</nfe:tpAmb>
                     <nfe:cUFAutor>35</nfe:cUFAutor>
                      <nfe:CNPJ>{}</nfe:CNPJ>
                      <nfe:consChNFe></nfe:consChNFe>
                      <nfe:distNSU></nfe:distNSU>
                      <nfe:ultNSU></nfe:ultNSU>
                   </nfe:distDFeInt>
                </nfe:nfeDistDFeInteresse>
              </soap:Body>
            </soap:Envelope>
            """.format(signature_base64, self.certificado_base64, xml_string)
        )
        return xml_cabecalho

    def consultar_nfe(self, cnpj, ult_nsu=None):
        xml_string = cnpj
        xml_cabecalho = self._montar_cabecalho(xml_string)
        headers = {'Content-Type': 'application/soap+xml;charset=utf-8'}
        url = "https://nfe.fazenda.sp.gov.br/ws/v1/NFeDistribuicaoDFe.asmx"
        response = requests.post(url, data=xml_cabecalho, headers=headers, cert=(self.certificado_path, self.senha_certificado), verify=False)
        if response.status_code == 200:
            xml_dict = xmltodict.parse(response.text)
            return xml_dict
        else:
            return None